package bubblesSimulation;

import java.util.List;

import org.lwjgl.opengl.Display;
import org.lwjgl.opengl.GL11;
import org.lwjgl.util.vector.Vector3f;

import entities.Entity;
import renderEngine.DisplayManager;
import renderEngine.Loader;
import models.RawModel;
import models.TextureModel;
import renderEngine.Renderer;
import renderEngine.SphereGenerator;
import shaders.StaticShader;
import textures.ModelTexture;

public class MainLoop {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		DisplayManager.createDisplay();
		
		//create objects of loader and renderer
		Loader loader = new Loader();
		StaticShader shader = new StaticShader();
		Renderer renderer = new Renderer(shader);

		
		float[] vertices_of_walls = {
				//left bottom
				-2.5f ,  2.5f , 0f, //v1  
				-2.5f , -2.5f , 0f, //v2
				 2.5f , -2.5f , 0f,	//v3
				 //right top
			     2.5f , -2.5f , 0f, //v3
			   	 2.5f ,  2.5f , 0f, //v4
			    -2.5f ,  2.5f , 0f  //v1
				
		};
		
		float [] texture_coords_of_walss= {
			0f,0f,
			0f,1f,
			1f,1f,
			1f,1f,
			1f,0f,
			0f,0f
		};
		RawModel model_wall = loader.loadToVAO(vertices_of_walls , texture_coords_of_walss);
		ModelTexture texture_wall = new ModelTexture(loader.loadTexture("ima4"));
		TextureModel textureModel_wall = new TextureModel(model_wall, texture_wall);
		Entity entity_wall = new Entity(textureModel_wall, new Vector3f(0f,0f ,-4f), 0, 0, 0, 1.2f);
		
		List<Float> al = SphereGenerator.generateSpherePositions(null , 0.3, 100, 100); //40000 vertex
        System.out.println(al.size());
        float [] positions = new float[al.size()];
        
        int ii=0;
		for (float i : al) {
        	positions[ii]=i;
        	//System.out.println(i);
        	//System.out.println(al1[ii]+" ");
        	ii++;}
		
		int size_of_uv_map =(positions.length/3)*2;
		float [] texture_coordinates=new float[size_of_uv_map] ;// uv array
		texture_coordinates=SphereGenerator.generateSphereUV(size_of_uv_map);		
				
   
		
		RawModel model = loader.loadToVAO(positions , texture_coordinates);
		ModelTexture texture = new ModelTexture(loader.loadTexture("ima"));
		TextureModel textureModel = new TextureModel(model, texture);

		Entity entity1 = new Entity(textureModel, new Vector3f(0f,0f ,0f), 0, 0, 0, 1);
		Entity entity2 = new Entity(textureModel, new Vector3f(-2f,0f ,-3f), 0, 0, 0, 1);
		Entity entity3 = new Entity(textureModel, new Vector3f(-1f,-1f ,-3f), 0, 0, 0, 1);
		Entity entity4 = new Entity(textureModel, new Vector3f(-1.8f,-1f ,-3f), 0, 0, 0, 1);
		Entity entity5 = new Entity(textureModel, new Vector3f(-0.3f,-1f ,-3f), 0, 0, 0, 1);
		//loop until press on "X"
		while(! Display.isCloseRequested()) {
			if(entity1.getPosition().z >-3)
			{entity1.increasePosition(0, 0, -0.01f);}
			else {
				entity1.increasePosition(-0.01f, 0f, 0f);
				entity2.increasePosition(+0.01f,0f ,0f );
			}
			entity1.increaseRotation(0.5f, 0.5f, 0.5f);
			entity3.increaseRotation(0.5f, 0.5f, 0.5f);
			entity4.increaseRotation(0.5f, 0.5f, 0.5f);
			entity5.increaseRotation(0.5f, 0.5f, 0.5f);
			
			renderer.prepare();
           shader.start();			
			//game logic 

			//render
           renderer.render(entity_wall, shader);
			renderer.render(entity1 , shader);
			renderer.render(entity2 , shader);
			renderer.render(entity3 , shader);
			renderer.render(entity4 , shader);
			renderer.render(entity5 , shader);
            
			shader.stop();
			
			DisplayManager.updateDisplay();
		}
		
		shader.cleanUP();
		loader.cleanUP();
		DisplayManager.closeDisplay();
		
	}

}
