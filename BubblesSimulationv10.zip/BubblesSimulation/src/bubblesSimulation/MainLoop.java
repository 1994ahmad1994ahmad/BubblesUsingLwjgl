package bubblesSimulation;

import org.lwjgl.opengl.Display;
import org.lwjgl.util.vector.Vector3f;

import entities.Camera;
import entities.Entity;
import entities.Light;
import renderEngine.DisplayManager;
import renderEngine.Loader;
import renderEngine.OBJLoader;
import models.RawModel;
import models.TextureModel;
import renderEngine.Renderer;
import shaders.StaticShader;
import textures.ModelTexture;

public class MainLoop {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		DisplayManager.createDisplay();
		
		//create objects of loader and renderer
		Loader loader = new Loader();
		StaticShader shader = new StaticShader();
		Renderer renderer = new Renderer(shader);

		/*
		float[] vertices_of_walls = {
				//left bottom
				-2.5f ,  2.5f , 0f, //v1  
				-2.5f , -2.5f , 0f, //v2
				 2.5f , -2.5f , 0f,	//v3
				 //right top
			     2.5f , -2.5f , 0f, //v3
			   	 2.5f ,  2.5f , 0f, //v4
			    -2.5f ,  2.5f , 0f  //v1
				
		};
		
		float [] texture_coords_of_walss= {
			0f,0f,
			0f,1f,
			1f,1f,
			1f,1f,
			1f,0f,
			0f,0f
		};
		RawModel model_wall = loader.loadToVAO(vertices_of_walls , texture_coords_of_walss);
		ModelTexture texture_wall = new ModelTexture(loader.loadTexture("ima4"));
		TextureModel textureModel_wall = new TextureModel(model_wall, texture_wall);
		Entity entity_wall = new Entity(textureModel_wall, new Vector3f(0f,0f ,-4f), 0, 0, 0, 1.2f);
		*/
		
		/*
		List<Float> al = SphereGenerator.generateSpherePositions(null , 0.3, 100, 100); //40000 vertex
        System.out.println(al.size());
        float [] positions = new float[al.size()];
        
        int ii=0;
		for (float i : al) {
        	positions[ii]=i;
        	//System.out.println(i);
        	//System.out.println(al1[ii]+" ");
        	ii++;}
		
		int size_of_uv_map =(positions.length/3)*2;
		float [] texture_coordinates=new float[size_of_uv_map] ;// uv array
		texture_coordinates=SphereGenerator.generateSphereUV(size_of_uv_map);		
				
   
		
	//	RawModel model = loader.loadToVAO(positions , texture_coordinates);
	//	ModelTexture texture = new ModelTexture(loader.loadTexture("ima"));
	//	TextureModel textureModel = new TextureModel(model, texture);

	//	Entity entity1 = new Entity(textureModel, new Vector3f(0f,0f ,0f), 0, 0, 0, 1);
	//	Entity entity2 = new Entity(textureModel, new Vector3f(-2f,0f ,-3f), 0, 0, 0, 1);
	//	Entity entity3 = new Entity(textureModel, new Vector3f(-1f,-1f ,-3f), 0, 0, 0, 1);
	//	Entity entity4 = new Entity(textureModel, new Vector3f(-1.8f,-1f ,-3f), 0, 0, 0, 1);
	//	Entity entity5 = new Entity(textureModel, new Vector3f(-0.3f,-1f ,-3f), 0, 0, 0, 1);
		*/
		
		RawModel myobj = OBJLoader.loadObjModel("firstBubble" , loader);
		ModelTexture myobj_texture = new ModelTexture(loader.loadTexture("firstBubble"));
		TextureModel myobj_textureModel = new TextureModel(myobj, myobj_texture);
		Entity bubble1 = new Entity(myobj_textureModel, new Vector3f(3f,0f ,-10f), 0f, 0f, 0f, 1f);
		Entity bubble2 = new Entity(myobj_textureModel, new Vector3f(-3f,0f ,-10f), 0f, 0f, 0f, 1f);

		RawModel myobj_FG = OBJLoader.loadObjModel("beforeCompleteCollision0" , loader);
		ModelTexture myobj_FG__texture = new ModelTexture(loader.loadTexture("firstBubble"));
		TextureModel myobj_FG__textureModel = new TextureModel(myobj_FG, myobj_FG__texture);
		Entity bcc0 = new Entity(myobj_FG__textureModel, new Vector3f(0.5f,0f ,-10f), 0f, 0f, 0f, 1f);

		RawModel myobj_FG1 = OBJLoader.loadObjModel("beforeCompleteCollision1" , loader);
		ModelTexture myobj_FG__texture1 = new ModelTexture(loader.loadTexture("firstBubble"));
		TextureModel myobj_FG__textureModel1 = new TextureModel(myobj_FG1, myobj_FG__texture1);
		Entity bcc1 = new Entity(myobj_FG__textureModel1, new Vector3f(0.5f,0f ,-10f), 0f, 0f, 0f, 1f);

		RawModel myobj_FG2 = OBJLoader.loadObjModel("beforeCompleteCollision2" , loader);
		ModelTexture myobj_FG__texture2 = new ModelTexture(loader.loadTexture("firstBubble"));
		TextureModel myobj_FG__textureModel2 = new TextureModel(myobj_FG2, myobj_FG__texture2);
		Entity bcc2 = new Entity(myobj_FG__textureModel2, new Vector3f(0.5f,0f ,-10f), 0f, 0f, 0f, 1f);

		
		RawModel myobj_FG3 = OBJLoader.loadObjModel("beforeCompleteCollision3" , loader);
		ModelTexture myobj_FG__texture3 = new ModelTexture(loader.loadTexture("firstBubble"));
		TextureModel myobj_FG__textureModel3 = new TextureModel(myobj_FG3, myobj_FG__texture3);
		Entity bcc3 = new Entity(myobj_FG__textureModel3, new Vector3f(0.5f,0f ,-10f), 0f, 0f, 0f, 1f);

		
		Entity bubble3 = new Entity(myobj_textureModel, new Vector3f(-10f,-12f ,-7f), 0f, 0f, 0f, 1f);
		Entity bubble4 = new Entity(myobj_textureModel, new Vector3f(-7f,-10f ,-7f), 0f, 0f, 0f, 1f);
		Entity bubble5 = new Entity(myobj_textureModel, new Vector3f(-3f,-12f ,-7f), 0f, 0f, 0f, 1f);
		Entity bubble6 = new Entity(myobj_textureModel, new Vector3f(0f,-10f ,-7f), 0f, 0f, 0f, 1f);
		Entity bubble7 = new Entity(myobj_textureModel, new Vector3f(3f,-12f ,-7f), 0f, 0f, 0f, 1f);
		Entity bubble8 = new Entity(myobj_textureModel, new Vector3f(6f,-10f ,-7f), 0f, 0f, 0f, 1f);
		Entity bubble9 = new Entity(myobj_textureModel, new Vector3f(9f,-12f ,-7f), 0f, 0f, 0f, 1f);
		
		
		RawModel wallOBJ = OBJLoader.loadObjModel("wall" , loader);
		ModelTexture wall_texture = new ModelTexture(loader.loadTexture("background"));
		TextureModel wall_textureModel = new TextureModel(wallOBJ, wall_texture);
		Entity wall = new Entity(wall_textureModel, new Vector3f(0f,0f ,-12f), 90f, 0f, 0f, 1f);
		
		
		
		
		
		Light light1 = new Light(new Vector3f(0f , 0.0f, 100.0f ) , new Vector3f(0.01f , 0.01f ,0.01f));
		Light light2 = new Light(new Vector3f(0f , 0.0f, 50f ) , new Vector3f(0.8f , 0.8f ,0.8f));
		Camera camera = new Camera();
		Vector3f camera_position =camera.getPosition();
		camera_position.z +=6;
		camera.setPosition(camera_position);
		
		float before_complete_collision = 1.0f;
		
		float scale_after_collision = 1.3f;
		//loop until press on "X"
		while(! Display.isCloseRequested()) {
		
		//	if(entity1.getPosition().z >-3)
		//	{entity1.increasePosition(0, 0, -0.01f);}
		//	else {
		//		entity1.increasePosition(-0.01f, 0f, 0f);
		//		entity2.increasePosition(+0.01f,0f ,0f );
		//	}
		//	entity1.increaseRotation(0.5f, 0.5f, 0.5f);
		//	entity3.increaseRotation(0.5f, 0.5f, 0.5f);
		//	entity4.increaseRotation(0.5f, 0.5f, 0.5f);
		//	entity5.increaseRotation(0.5f, 0.5f, 0.5f);
	           
			bubble3.increasePosition(0f, 0.01f, 0f);
			bubble4.increasePosition(0f, 0.01f, 0f);
			bubble5.increasePosition(0f, 0.01f, 0f);
			bubble6.increasePosition(0f, 0.01f, 0f);
			bubble7.increasePosition(0f, 0.01f, 0f);
			bubble8.increasePosition(0f, 0.01f, 0f);
			bubble9.increasePosition(0f, 0.01f, 0f);
			camera.move();
			renderer.prepare();
           shader.start();
           shader.loadLight(light1);
           shader.loadLight(light2);
           shader.loadViewMatrix(camera);
			//game logic 

			//render
        //   renderer.render(entity_wall, shader);
		//	renderer.render(entity1 , shader);
		//	renderer.render(entity2 , shader);
		//	renderer.render(entity3 , shader);
		//	renderer.render(entity4 , shader);
		//	renderer.render(entity5 , shader);
           //myobj_entity.increaseRotation(0f ,  0.5f , 0f );
          
           if(bubble1.getPosition().x > 1.3f) {
				bubble1.increasePosition(-0.007f, 0f, 0f);    
          }
			if(bubble2.getPosition().x < -1.3f) {
				bubble2.increasePosition(0.007f, 0f, 0f);
				renderer.render(bubble1 ,shader);
		           renderer.render(bubble2 ,shader);      
			}
			else {
				if(before_complete_collision <= 1.20) {
					if(before_complete_collision<1.05) {
					before_complete_collision +=0.001f;
				//bubble1.setScale(increase_size);
				//bubble2.setScale(increase_size);
					   renderer.render(bcc0 ,shader);		   
					  // bubbleG1.setRoY(0.1f);
					}
					else if(before_complete_collision<=1.10) {
						before_complete_collision +=0.001f;
						 renderer.render(bcc1 ,shader);
					}
					else if(before_complete_collision<=1.15) {
						before_complete_collision +=0.001f;
						 renderer.render(bcc2 ,shader);
					}
					else if(before_complete_collision<1.20) {
						before_complete_collision +=0.001f;
						 renderer.render(bcc3 ,shader);
					}
					
				}
				else {
					if(scale_after_collision <1.5f) {//keep scaling
					bubble1.setPosition(new Vector3f(0f,0f,-10f));
					scale_after_collision+=0.001f;
					bubble1.setScale(scale_after_collision);
					renderer.render(bubble1 ,shader);
					}
					else { //move the one bubble collision upward
						bubble1.increasePosition(0f, 0.01f,0f);
						renderer.render(bubble1 ,shader);
					}
				}
			}		
		
           
           renderer.render(bubble3, shader);
           renderer.render(bubble4, shader);
           renderer.render(bubble5, shader);
           renderer.render(bubble6, shader);
           renderer.render(bubble7, shader);
           renderer.render(bubble8, shader);
           renderer.render(bubble9, shader);
           
           renderer.render(wall, shader);
			shader.stop();
			
			DisplayManager.updateDisplay();
		}
		
		shader.cleanUP();
		loader.cleanUP();
		DisplayManager.closeDisplay();
		
	}

}
